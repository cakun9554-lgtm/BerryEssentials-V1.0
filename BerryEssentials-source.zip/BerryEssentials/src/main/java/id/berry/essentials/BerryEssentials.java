package id.berry.essentials;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Sign;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** BerryEssentials - Paper 26.3 / Java 25. Land-claim intentionally omitted. */
public final class BerryEssentials extends JavaPlugin implements Listener, CommandExecutor {
    private File dataFile; private YamlConfiguration data;
    private final Map<UUID, UUID> tpa = new HashMap<>();
    private final Map<UUID, Long> rtpCooldown = new HashMap<>();
    private final Random random = new Random();
    private NamespacedKey npcKey;
    private static final String MENU = "§5BerryEssentials Menu", SHOP = "§5Berry Shop", QUEST = "§5Daily Quest", PASS = "§5Berry Battlepass";

    @Override public void onEnable() {
        saveDefaultConfig(); npcKey = new NamespacedKey(this, "berry_npc");
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) try { getDataFolder().mkdirs(); dataFile.createNewFile(); } catch (IOException ex) { throw new IllegalStateException(ex); }
        data = YamlConfiguration.loadConfiguration(dataFile);
        getServer().getPluginManager().registerEvents(this, this);
        for (String name : List.of("berry","money","bank","pay","sethome","home","delhome","setwarp","warp","delwarp","tpa","tpaccept","rtp","shop","backpack","clan","quest","battlepass","rank","berryadmin","npc","chestshop")) {
            PluginCommand command = getCommand(name); if (command != null) command.setExecutor(this);
        }
        long period = Math.max(20, getConfig().getLong("scoreboard.update-ticks", 40));
        getServer().getScheduler().runTaskTimer(this, () -> Bukkit.getOnlinePlayers().forEach(this::updateBoard), 20L, period);
        getLogger().info("BerryEssentials 0.2.0 enabled; Land Claim is excluded.");
    }
    @Override public void onDisable() { saveData(); }
    private void saveData() { if (data != null && dataFile != null) try { data.save(dataFile); } catch (IOException ex) { getLogger().severe("Failed saving data.yml: " + ex.getMessage()); } }
    private String path(Player p, String key) { return "players." + p.getUniqueId() + "." + key; }
    private double wallet(Player p) { return data.getDouble(path(p,"money"), getConfig().getDouble("economy.starting-balance",0)); }
    private double bank(Player p) { return data.getDouble(path(p,"bank"),0); }
    private void wallet(Player p,double value) { data.set(path(p,"money"), Math.max(0,value)); saveData(); }
    private void bank(Player p,double value) { data.set(path(p,"bank"), Math.max(0,value)); saveData(); }
    private String rank(Player p) { return data.getString(path(p,"rank"),"MEMBER").toUpperCase(Locale.ROOT); }
    private String clan(Player p) { return data.getString(path(p,"clan"),"None"); }
    private void msg(CommandSender s,String text) { s.sendMessage("§8[§5Berry§6Essentials§8] §f" + ChatColor.translateAlternateColorCodes('&',text)); }
    private ItemStack item(Material type,String name,String... lore) { ItemStack stack=new ItemStack(type); ItemMeta meta=stack.getItemMeta(); meta.setDisplayName(name); meta.setLore(Arrays.asList(lore)); stack.setItemMeta(meta); return stack; }
    private double amount(String text) { try { double n=Double.parseDouble(text); return Double.isFinite(n)&&n>0?n:-1; } catch(Exception ex){return -1;} }
    private String money(double n) { return String.format(Locale.US,"%,.2f",n); }
    private String shortMoney(double n) { return n>=1_000_000?String.format(Locale.US,"%.1fM",n/1_000_000):n>=1_000?String.format(Locale.US,"%.1fK",n/1_000):String.format(Locale.US,"%.0f",n); }

    // Sidebar intentionally uses text only. Vanilla sidebar cannot draw a bitmap logo, frame, or background texture.
    private void updateBoard(Player p) {
        if (!getConfig().getBoolean("scoreboard.enabled",true)) return;
        Scoreboard board=Bukkit.getScoreboardManager().getNewScoreboard();
        Objective objective=board.registerNewObjective("berry","dummy", "§9§lBerry§6§lEssentials"); objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        String dim=switch(p.getWorld().getEnvironment()){case NETHER->"Nether";case THE_END->"The End";default->"Overworld";};
        double kills=data.getDouble(path(p,"kills"),0), deaths=data.getDouble(path(p,"deaths"),0);
        String kd=String.format(Locale.US,"%.1f",kills/Math.max(1,deaths));
        List<String> lines=List.of("§8 ","§c§lPROFILES","§f▪ NAME : §b"+p.getName(),"§f▪ MONEY : §a$"+shortMoney(wallet(p)),"§f▪ CLAN : §d"+clan(p),"§f▪ RANK : §e§l"+rank(p),"§8  ","§c§lSERVERS","§f▪ ONLINE : §a"+Bukkit.getOnlinePlayers().size()+"/"+Bukkit.getMaxPlayers(),"§f▪ TPS : §a"+String.format(Locale.US,"%.1f",Bukkit.getTPS()[0]),"§f▪ K/D : §e"+kd,"§f▪ DIM : §b"+dim);
        int score=lines.size(); for(String line:lines) objective.getScore(line).setScore(score--);
        // Team prefix syncs rank color with the player's nametag on this scoreboard.
        Team team=board.registerNewTeam("r"+Math.abs(rank(p).hashCode()%100000));
        ChatColor color=rankColor(rank(p)); team.setColor(color); team.setPrefix(color+"["+rank(p)+"] "); team.addEntry(p.getName());
        p.setScoreboard(board);
    }
    private ChatColor rankColor(String r) { return switch(r){case "OWNER"->ChatColor.LIGHT_PURPLE;case "ADMIN"->ChatColor.RED;case "MOD"->ChatColor.AQUA;case "VIP"->ChatColor.GOLD;default->ChatColor.YELLOW;}; }
    @EventHandler public void onJoin(PlayerJoinEvent e) { Player p=e.getPlayer(); data.set(path(p,"last-name"),p.getName()); String today=java.time.LocalDate.now().toString(); if(!today.equals(data.getString(path(p,"quest-date"),""))){data.set(path(p,"quest-date"),today);data.set(path(p,"quest-kills"),0);data.set(path(p,"quest-claimed"),false);} if(!data.contains(path(p,"money")))data.set(path(p,"money"),getConfig().getDouble("economy.starting-balance",0)); saveData(); Bukkit.getScheduler().runTask(this,()->updateBoard(p)); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { tpa.remove(e.getPlayer().getUniqueId()); }
    @EventHandler public void onDeath(PlayerDeathEvent e) { Player p=e.getEntity(); data.set(path(p,"deaths"),data.getDouble(path(p,"deaths"),0)+1); saveData(); }
    @EventHandler public void onKill(EntityDeathEvent e) { Player killer=e.getEntity().getKiller(); if(killer!=null){data.set(path(killer,"kills"),data.getDouble(path(killer,"kills"),0)+1); int q=data.getInt(path(killer,"quest-kills"),0)+1; data.set(path(killer,"quest-kills"),q); data.set(path(killer,"pass-points"),data.getInt(path(killer,"pass-points"),0)+getConfig().getInt("battlepass.points-per-kill",10)); if(q>=getConfig().getInt("quests.daily-kill-goal",5)&&!data.getBoolean(path(killer,"quest-claimed"),false)) msg(killer,"Daily quest selesai! Klaim hadiah dengan /quest claim."); saveData(); updateBoard(killer);} }

    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] a) {
        String c=command.getName().toLowerCase(Locale.ROOT); Player p=sender instanceof Player pl?pl:null;
        if(p==null && !List.of("setwarp","delwarp","rank","berryadmin").contains(c)){msg(sender,"Command ini hanya bisa dipakai pemain.");return true;}
        switch(c) {
            case "berry" -> openMain(p);
            case "money" -> msg(p,"Wallet: &a$"+money(wallet(p))+" &7| Bank: &e$"+money(bank(p)));
            case "bank" -> { if(a.length!=2){msg(p,"Gunakan /bank deposit|withdraw jumlah");break;} double n=amount(a[1]); if(n<0){msg(p,"Jumlah tidak valid.");break;} if(a[0].equalsIgnoreCase("deposit")&&wallet(p)>=n){wallet(p,wallet(p)-n);bank(p,bank(p)+n);msg(p,"Deposit berhasil.");}else if(a[0].equalsIgnoreCase("withdraw")&&bank(p)>=n){bank(p,bank(p)-n);wallet(p,wallet(p)+n);msg(p,"Withdraw berhasil.");}else msg(p,"Saldo tidak cukup atau aksi salah."); }
            case "pay" -> { if(a.length!=2){msg(p,"Gunakan /pay pemain jumlah");break;} Player t=Bukkit.getPlayerExact(a[0]);double n=amount(a[1]);if(t==null||t.equals(p)||n<0||wallet(p)<n){msg(p,"Pemain/jumlah tidak valid atau saldo kurang.");break;}wallet(p,wallet(p)-n);wallet(t,wallet(t)+n);msg(p,"Transfer $"+money(n)+" ke "+t.getName()+" berhasil.");msg(t,"Kamu menerima $"+money(n)+" dari "+p.getName()); }
            case "sethome" -> { String h=a.length>0?a[0].toLowerCase():"home";ConfigurationSection hs=data.getConfigurationSection(path(p,"homes"));if(hs==null)hs=data.createSection(path(p,"homes"));int max=getConfig().getInt("homes.max-per-player",3);if(!hs.contains(h)&&hs.getKeys(false).size()>=max){msg(p,"Batas home tercapai.");break;}hs.set(h,serialize(p.getLocation()));saveData();msg(p,"Home "+h+" disimpan."); }
            case "home" -> {String h=a.length>0?a[0].toLowerCase():"home";Location l=deserialize(data.getString(path(p,"homes."+h)));if(l==null){msg(p,"Home tidak ditemukan.");break;}p.teleportAsync(l);msg(p,"Teleport ke home.");}
            case "delhome" -> {if(a.length==0){msg(p,"Gunakan /delhome nama");break;}data.set(path(p,"homes."+a[0].toLowerCase()),null);saveData();msg(p,"Home dihapus.");}
            case "setwarp" -> {if(a.length==0){msg(sender,"Gunakan /setwarp nama");break;}data.set("warps."+a[0].toLowerCase(),serialize(p==null?Bukkit.getWorlds().getFirst().getSpawnLocation():p.getLocation()));saveData();msg(sender,"Warp disimpan.");}
            case "warp" -> {if(a.length==0){msg(p,"Gunakan /warp nama");break;}Location l=deserialize(data.getString("warps."+a[0].toLowerCase()));if(l==null){msg(p,"Warp tidak ditemukan.");break;}p.teleportAsync(l);msg(p,"Teleport ke warp.");}
            case "delwarp" -> {if(a.length==0){msg(sender,"Gunakan /delwarp nama");break;}data.set("warps."+a[0].toLowerCase(),null);saveData();msg(sender,"Warp dihapus.");}
            case "tpa" -> {if(a.length==0){msg(p,"Gunakan /tpa pemain");break;}Player t=Bukkit.getPlayerExact(a[0]);if(t==null||t.equals(p)){msg(p,"Pemain tidak ditemukan.");break;}tpa.put(t.getUniqueId(),p.getUniqueId());msg(p,"Request dikirim ke "+t.getName());msg(t,p.getName()+" meminta teleportasi. Ketik /tpaccept");}
            case "tpaccept" -> {UUID id=tpa.remove(p.getUniqueId());Player requester=id==null?null:Bukkit.getPlayer(id);if(requester==null){msg(p,"Tidak ada request aktif.");break;}requester.teleportAsync(p.getLocation());msg(p,"Request diterima.");msg(requester,"Request diterima.");}
            case "rtp" -> randomTeleport(p);
            case "shop" -> openShop(p);
            case "backpack" -> openBackpack(p);
            case "clan" -> clanCommand(p,a);
            case "quest" -> questCommand(p,a);
            case "battlepass" -> {if(a.length>0&&a[0].equalsIgnoreCase("claim")){int points=data.getInt(path(p,"pass-points"),0),level=points/Math.max(1,getConfig().getInt("battlepass.points-per-level",100)),claimed=data.getInt(path(p,"pass-claimed-level"),0);if(level<=claimed){msg(p,"Belum ada reward battlepass baru.");break;}double reward=level*100.0;wallet(p,wallet(p)+reward);data.set(path(p,"pass-claimed-level"),level);saveData();msg(p,"Reward battlepass level "+level+": $"+money(reward));}else openBattlepass(p);}
            case "rank" -> {if(!sender.hasPermission("berry.admin")){msg(sender,"Tidak punya izin.");break;}if(a.length<2){msg(sender,"Gunakan /rank pemain rank");break;}Player t=Bukkit.getPlayerExact(a[0]);if(t==null){msg(sender,"Pemain harus online.");break;}data.set(path(t,"rank"),a[1].toUpperCase(Locale.ROOT));saveData();updateBoard(t);msg(sender,"Rank pemain diperbarui.");}
            case "berryadmin" -> {if(p!=null)openAdmin(p);}
            case "npc" -> npcCommand(p,a);
            case "chestshop" -> msg(p,"Buat chest shop: taruh sign pada chest, baris 1 [BerryShop], baris 2 MATERIAL, baris 3 HARGA, baris 4 BUY atau SELL.");
        }
        if(p!=null)updateBoard(p);return true;
    }
    private String serialize(Location l){return l.getWorld().getName()+";"+l.getX()+";"+l.getY()+";"+l.getZ()+";"+l.getYaw()+";"+l.getPitch();}
    private Location deserialize(String s){if(s==null)return null;String[] a=s.split(";");if(a.length!=6)return null;World w=Bukkit.getWorld(a[0]);if(w==null)return null;try{return new Location(w,Double.parseDouble(a[1]),Double.parseDouble(a[2]),Double.parseDouble(a[3]),Float.parseFloat(a[4]),Float.parseFloat(a[5]));}catch(Exception ex){return null;}}
    private void randomTeleport(Player p){long now=System.currentTimeMillis(),last=rtpCooldown.getOrDefault(p.getUniqueId(),0L);long wait=getConfig().getLong("rtp.cooldown-seconds",60)-(now-last)/1000;if(wait>0){msg(p,"Tunggu "+wait+" detik untuk RTP lagi.");return;}World w=p.getWorld();int radius=Math.max(100,getConfig().getInt("rtp.radius",5000));for(int i=0;i<getConfig().getInt("rtp.attempts",40);i++){int x=random.nextInt(radius*2+1)-radius,z=random.nextInt(radius*2+1)-radius;int y=w.getHighestBlockYAt(x,z)+1;Location l=new Location(w,x+.5,y,z+.5);if(y>w.getMinHeight()&&y<w.getMaxHeight()-2&&l.getBlock().isPassable()&&l.clone().add(0,1,0).getBlock().isPassable()&&l.clone().subtract(0,1,0).getBlock().getType().isSolid()){p.teleportAsync(l);rtpCooldown.put(p.getUniqueId(),now);msg(p,"RTP berhasil.");return;}}msg(p,"Lokasi aman tidak ditemukan, coba lagi.");}

    private void openMain(Player p){Inventory inv=Bukkit.createInventory(null,36,MENU);inv.setItem(10,item(Material.GOLD_INGOT,"§eEconomy & Bank","§7/money, /bank, /pay"));inv.setItem(12,item(Material.EMERALD,"§aCustom Shop","§7Buka toko"));inv.setItem(14,item(Material.COMPASS,"§bTravel","§7Home, warp, RTP, TPA"));inv.setItem(16,item(Material.CHEST,"§6Backpack","§7Penyimpanan pribadi"));inv.setItem(20,item(Material.SHIELD,"§dClan","§7Sistem clan"));inv.setItem(22,item(Material.BOOK,"§cQuest","§7Daily quest"));inv.setItem(24,item(Material.NETHER_STAR,"§6Battlepass","§7Progress dan reward"));p.openInventory(inv);}
    private void openShop(Player p){Inventory inv=Bukkit.createInventory(null,54,SHOP);ConfigurationSection sec=getConfig().getConfigurationSection("shop");if(sec!=null){int slot=0;for(String k:sec.getKeys(false)){Material m=Material.matchMaterial(k);if(m!=null&&slot<45)inv.setItem(slot++,item(m,"§aBuy "+k,"§7Price: §e$"+money(sec.getDouble(k)),"§8Klik untuk membeli"));}}p.openInventory(inv);}
    private void openBackpack(Player p){int rows=Math.max(1,Math.min(6,getConfig().getInt("backpack.rows",3)));Inventory inv=Bukkit.createInventory(null,rows*9,"§5Backpack");List<?> items=data.getList(path(p,"backpack"));if(items!=null)for(int i=0;i<Math.min(items.size(),inv.getSize());i++)if(items.get(i) instanceof ItemStack stack)inv.setItem(i,stack);p.openInventory(inv);}
    private void openBattlepass(Player p){Inventory inv=Bukkit.createInventory(null,27,PASS);int points=data.getInt(path(p,"pass-points"),0),level=points/Math.max(1,getConfig().getInt("battlepass.points-per-level",100));inv.setItem(13,item(Material.NETHER_STAR,"§6Battlepass Level "+level,"§7Points: "+points,"§7Earn points by defeating mobs.","§e/battlepass claim to claim next reward"));p.openInventory(inv);}
    private void openQuest(Player p){int kills=data.getInt(path(p,"quest-kills"),0),goal=getConfig().getInt("quests.daily-kill-goal",5);Inventory inv=Bukkit.createInventory(null,27,QUEST);inv.setItem(13,item(Material.ZOMBIE_HEAD,"§cDaily Hunt: "+Math.min(kills,goal)+"/"+goal,"§7Reward: $"+getConfig().getDouble("quests.daily-reward",250),data.getBoolean(path(p,"quest-claimed"),false)?"§cAlready claimed":"§eClick to claim when complete"));p.openInventory(inv);}
    private void openAdmin(Player p){Inventory inv=Bukkit.createInventory(null,27,"§4Berry Admin");inv.setItem(11,item(Material.NAME_TAG,"§eNPC Help","§7/npc create <name>"));inv.setItem(13,item(Material.PAPER,"§eWarp Help","§7/setwarp, /delwarp"));inv.setItem(15,item(Material.DIAMOND,"§eRank Help","§7/rank <player> <rank>"));p.openInventory(inv);}
    private void clanCommand(Player p,String[] a){if(a.length==0){msg(p,"/clan create <nama>, /clan invite <player>, /clan join <nama>, /clan leave, /clan info");return;}String sub=a[0].toLowerCase();if(sub.equals("create")&&a.length>1){String name=a[1].replaceAll("[^A-Za-z0-9_]","");if(name.length()<3||name.length()>12){msg(p,"Nama clan harus 3-12 karakter.");return;}String existing=data.getString("clans."+name+".owner");if(existing!=null){msg(p,"Nama clan sudah dipakai.");return;}String old=clan(p);if(!old.equals("None")){msg(p,"Keluar dari clan lama dulu.");return;}data.set("clans."+name+".owner",p.getUniqueId().toString());data.set("clans."+name+".members",List.of(p.getUniqueId().toString()));data.set(path(p,"clan"),name);saveData();msg(p,"Clan "+name+" berhasil dibuat.");}else if(sub.equals("leave")){String name=clan(p);if(name.equals("None")){msg(p,"Kamu belum punya clan.");return;}data.getStringList("clans."+name+".members").remove(p.getUniqueId().toString());data.set(path(p,"clan"),"None");saveData();msg(p,"Kamu keluar dari clan.");}else if(sub.equals("join")&&a.length>1){String name=a[1];if(!data.contains("clans."+name+".owner")||!name.equals(data.getString("invites."+p.getUniqueId(),""))){msg(p,"Tidak ada undangan clan yang cocok.");return;}if(!clan(p).equals("None")){msg(p,"Keluar dari clan lama dulu.");return;}List<String> members=data.getStringList("clans."+name+".members");members.add(p.getUniqueId().toString());data.set("clans."+name+".members",members);data.set(path(p,"clan"),name);data.set("invites."+p.getUniqueId(),null);saveData();msg(p,"Berhasil bergabung ke "+name);}else if(sub.equals("info")){String name=clan(p);msg(p,"Clan: "+name+(name.equals("None")?"":" | Members: "+data.getStringList("clans."+name+".members").size()));}else if(sub.equals("invite")&&a.length>1){String name=clan(p);Player t=Bukkit.getPlayerExact(a[1]);if(name.equals("None")||t==null){msg(p,"Clan/player tidak valid.");return;}if(!Objects.equals(data.getString("clans."+name+".owner"),p.getUniqueId().toString())){msg(p,"Hanya owner yang bisa mengundang.");return;}data.set("invites."+t.getUniqueId(),name);saveData();msg(p,"Undangan terkirim.");msg(t,"Undangan clan "+name+"; ketik /clan join "+name); }else msg(p,"Subcommand clan tidak valid.");updateBoard(p);}
    private void questCommand(Player p,String[] a){if(a.length>0&&a[0].equalsIgnoreCase("claim")){int goal=getConfig().getInt("quests.daily-kill-goal",5);if(data.getInt(path(p,"quest-kills"),0)<goal||data.getBoolean(path(p,"quest-claimed"),false)){msg(p,"Quest belum selesai atau sudah diklaim.");return;}double reward=getConfig().getDouble("quests.daily-reward",250);wallet(p,wallet(p)+reward);data.set(path(p,"quest-claimed"),true);saveData();msg(p,"Hadiah quest $"+money(reward)+" diterima.");}else openQuest(p);}
    private void npcCommand(Player p,String[] a){if(a.length>=2&&a[0].equalsIgnoreCase("create")){String name=String.join(" ",Arrays.copyOfRange(a,1,a.length));Villager v=(Villager)p.getWorld().spawnEntity(p.getLocation(),EntityType.VILLAGER);v.setCustomName("§d"+name);v.setCustomNameVisible(true);v.setAI(false);v.setInvulnerable(true);v.getPersistentDataContainer().set(npcKey,PersistentDataType.BYTE,(byte)1);msg(p,"NPC dialog dibuat. Klik NPC untuk membuka menu Berry.");}else msg(p,"Gunakan /npc create <nama>.");}
    @EventHandler public void onInteract(PlayerInteractEntityEvent e){if(e.getRightClicked().getPersistentDataContainer().has(npcKey,PersistentDataType.BYTE)){e.setCancelled(true);openMain(e.getPlayer());}}
    @EventHandler public void onInventoryClick(InventoryClickEvent e){if(!(e.getWhoClicked() instanceof Player p))return;String title=e.getView().getTitle();if(title.equals(MENU)){e.setCancelled(true);switch(e.getRawSlot()){case 10->msg(p,"Wallet $"+money(wallet(p))+" | Bank $"+money(bank(p)));case 12->openShop(p);case 14->msg(p,"Gunakan /home, /warp, /rtp, /tpa");case 16->openBackpack(p);case 20->clanCommand(p,new String[]{"info"});case 22->openQuest(p);case 24->openBattlepass(p);}return;}if(title.equals(SHOP)){e.setCancelled(true);ItemStack clicked=e.getCurrentItem();if(clicked==null||clicked.getType().isAir())return;double price=getConfig().getDouble("shop."+clicked.getType().name(),-1);if(price<0)return;if(wallet(p)<price){msg(p,"Saldo tidak cukup.");return;}wallet(p,wallet(p)-price);Map<Integer,ItemStack> leftover=p.getInventory().addItem(new ItemStack(clicked.getType()));leftover.values().forEach(item->p.getWorld().dropItemNaturally(p.getLocation(),item));msg(p,"Berhasil membeli "+clicked.getType()+".");updateBoard(p);return;}if(title.equals(QUEST)){e.setCancelled(true);questCommand(p,new String[]{"claim"});p.closeInventory();return;}if(title.equals(PASS)||title.equals("§4Berry Admin")){e.setCancelled(true);return;}}
    @EventHandler public void onInventoryClose(org.bukkit.event.inventory.InventoryCloseEvent e){if(e.getView().getTitle().equals("§5Backpack")&&e.getPlayer() instanceof Player p){data.set(path(p,"backpack"),Arrays.asList(e.getInventory().getContents()));saveData();}}

    // Chest shops: place a sign on/next to a chest; owner is the sign creator.
    @EventHandler public void onSignCreate(SignChangeEvent e){if(!e.getLine(0).equalsIgnoreCase("[BerryShop]"))return;if(!e.getPlayer().hasPermission("berry.admin")){e.setCancelled(true);msg(e.getPlayer(),"Butuh permission berry.admin untuk membuat chest shop.");return;}Material mat=Material.matchMaterial(e.getLine(1));double price=amount(e.getLine(2));if(mat==null||price<0||(!e.getLine(3).equalsIgnoreCase("BUY")&&!e.getLine(3).equalsIgnoreCase("SELL"))){e.setCancelled(true);msg(e.getPlayer(),"Format: [BerryShop] | MATERIAL | HARGA | BUY/SELL");return;}e.setLine(0,"§5[BerryShop]");e.setLine(1,mat.name());e.setLine(2,"$"+price);e.setLine(3,e.getLine(3).toUpperCase(Locale.ROOT));e.getBlock().getState().getPersistentDataContainer().set(new NamespacedKey(this,"shop-owner"),PersistentDataType.STRING,e.getPlayer().getUniqueId().toString());}
    @EventHandler public void onSignUse(PlayerInteractEvent e){if(e.getAction()!=org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK||e.getClickedBlock()==null)return;Block b=e.getClickedBlock();if(!(b.getState() instanceof Sign sign)||!ChatColor.stripColor(sign.getLine(0)).equalsIgnoreCase("[BerryShop]"))return;e.setCancelled(true);Player p=e.getPlayer();Material mat=Material.matchMaterial(ChatColor.stripColor(sign.getLine(1)));double price;try{price=Double.parseDouble(ChatColor.stripColor(sign.getLine(2)).replace("$",""));}catch(Exception ex){return;}if(mat==null)return;String mode=ChatColor.stripColor(sign.getLine(3));Block chest=b.getRelative(org.bukkit.block.BlockFace.DOWN);org.bukkit.block.Chest cs;if(chest.getState() instanceof org.bukkit.block.Chest found){cs=found;}else{chest=b.getRelative(org.bukkit.block.BlockFace.UP);if(!(chest.getState() instanceof org.bukkit.block.Chest found)){msg(p,"Chest shop harus ditempel pada chest.");return;}cs=found;}Inventory inv=cs.getBlockInventory();if(mode.equalsIgnoreCase("BUY")){if(wallet(p)<price){msg(p,"Saldo tidak cukup.");return;}if(inv.first(mat)==-1){msg(p,"Stok toko habis.");return;}ItemStack one=new ItemStack(mat);if(p.getInventory().firstEmpty()==-1){msg(p,"Inventory penuh.");return;}inv.removeItem(one);wallet(p,wallet(p)-price);p.getInventory().addItem(one);msg(p,"Berhasil membeli "+mat.name());}else if(mode.equalsIgnoreCase("SELL")){ItemStack found=null;for(ItemStack it:p.getInventory().getContents())if(it!=null&&it.getType()==mat&&it.getAmount()>0){found=it;break;}if(found==null){msg(p,"Kamu tidak punya item tersebut.");return;}found.setAmount(found.getAmount()-1);inv.addItem(new ItemStack(mat));wallet(p,wallet(p)+price);msg(p,"Item terjual.");}}
}
